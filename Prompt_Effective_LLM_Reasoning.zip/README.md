# 🧠 Prompting for Effective LLM Reasoning – Smart Policy Advisor

This project uses structured LLM prompting (chain-of-thought, few-shot) to simulate expert reasoning for rural livestock policy design.

## 📌 Features
- Multi-step reasoning prompts
- Problem understanding → Policy design → Risk analysis
- Based on LangChain + OpenAI GPT-4
- Ideal for Udacity's "Prompting for Effective LLM Reasoning" course

## 🚀 How to Run
1. Clone this repo or unzip the project
2. Install dependencies:

```bash
pip install openai langchain python-dotenv
```

3. Add your `.env` file:

```env
OPENAI_API_KEY=your_openai_key
```

4. Open and run `main.ipynb`

## 📥 Outputs

Example result:
- Challenges: Transport bottlenecks, price fluctuation, limited vet access
- Policies: Mobile clinics, co-op transport, cold storage
- Risks: High cost, lack of coordination, infrastructure gaps

## 👨‍💻 Author: Jemal Tahir Mumed
MSc in Agribusiness and Value Chain Management  
[LinkedIn](https://www.linkedin.com/jemal-tahir-33b39a1b7) | [GitHub](https://github.com/jemal-tahir)

## 📜 License: MIT
